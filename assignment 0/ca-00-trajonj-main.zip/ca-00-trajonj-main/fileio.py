__author__ = "Shishir Shah"
__version__ = "1.0.0"
__copyright__ = "Copyright 2022 by Shishir Shah, Quantitative Imaging Laboratory (QIL), Department of Computer  \
                Science, University of Houston.  All rights reserved.  This software is property of the QIL, and  \
                should not be distributed, reproduced, or shared online, without the permission of the author."

'''
Please fill in information below.
Github ID:
Name:
'''


def read_keyvalue(filename):
    # Write your code here
    pass # replace with appropriate return as needed


def read_message(filename):
    # Write your code here
    pass # replace with appropriate return as needed


def write_ciphered_messages(ciphered_message, filename):
    # Write your code here
    pass # replace with appropriate return as needed

